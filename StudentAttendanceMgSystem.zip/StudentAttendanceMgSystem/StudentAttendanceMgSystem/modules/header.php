<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Student Attendance Management System</title>
    
    <link href="css/bootstrap.min.css" rel="stylesheet">   
		<link href="css/style.css" rel="stylesheet">
		<script src="js/jquery.min.js"></script>
		<script src="js/validator.min.js"></script>
  </head>
  <body>
  
  	<div id="wrapper">
    <div class="overlay"></div>
    
    <h1>Student Attendance Management System</h1>
    <style>
      h1{
        margin-top:0;
        padding: 20px;
        background-color: #337ab7;
        color:white;
        text-align: center;
      }
      .sidebar-wrapper{
        color: white;
      }
    </style>