</div>
		<footer id="footer">
			<div id="">
			

			
				
			</p>
			</div>
			<div id="links">
			Developers: 
				<a href="#" taget="_blank">codingdiksha.com </a> 
				
			</div>
			
		</footer>
		<style>
			footer {
			position: fixed;
  			bottom: 0;
  			background-color: #373435;
  			width: 100%;
  			text-align: center; 
  			color: #fff;
  			padding-bottom: 10px;

			}	
			

			#footer a{
				margin-right:10px;
				text-decoration: none;
				color: white;
				padding-left:15px;
				padding-right:15px;
				margin-bottom:10px;
			}
			footer a:hover{
				color: white;
			}

		</style>
		<script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
  </body>
</html>